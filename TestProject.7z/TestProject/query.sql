//User_master

drop table User_Master;

create table User_Master 
(UserId varchar2(6),
UserName varchar2(15) NOT NULL,
UserPassword varchar2(50) NOT NULL,
UserType varchar2(10) NOT NULL,
Constraint pk_user Primary key(UserId));

insert into User_Master values('100001','Prince','prince','employee');

insert into User_Master values('100002','Pratik','pratik','admin');

insert into User_Master values('100003','Pratik','pratik','admin');




insert into User_Master values('202','riya@capge.com','riya23','admin');
insert into User_Master values('203','saras@capge.com','saras123','employee');
insert into User_Master values('204','vandu@capge.com','vandu123','employee');
insert into User_Master values('205','shikha@capge.com','shikha123','employee');
insert into User_Master values('206','ruchi@capge.com','ruchi123','employee');
insert into User_Master values('207','ranju@capge.com','ranju123','admin');
insert into User_Master values('208','payal@capge.com','payal123','employee');
insert into User_Master values('209','pooja@capge.com','pooja123','employee');
insert into User_Master values('210','anita@capge.com','anita123','employee');



//Department

drop table Department;


Create table Department
(Dept_ID int,
Dept_Name varchar2(50),
Constraint pk_dept primary key(Dept_ID));

insert into Department values('20','IT');
insert into Department values('10','Management');
insert into Department values('30','Finance');
insert into Department values('40','Marketing');
insert into Department values('50','HR');
select * from department;

//Grade_master

drop table Grade_Master;

create table Grade_Master
(Grade_Code varchar2(2),
Description varchar2(10),
Min_Salary int,
Max_Salary int,
Constraint pk_grade primary key(grade_code));

insert into Grade_Master values('M1','CEO','200000','40000');
insert into Grade_Master values('M2','Manager','100000','20000');
insert into Grade_Master values('M3','Team Leader','50000','10000');
insert into Grade_Master values('M4','Senior Software Engineer','250000','50000');
insert into Grade_Master values('M5','Software Engineer','20000','30000');
insert into Grade_Master values('M6','Associate','350000','300000');



//Employee

drop table Employee;

create table Employee
(Emp_ID varchar2(6),
Emp_First_Name varchar2(25),
Emp_Last_Name VARCHAR2(25),
Emp_Date_of_Birth Date,
Emp_Date_of_Joining Date,
Emp_Dept_ID int  NOT NULL,
Emp_Grade varchar2(2),
Emp_Basic int not null,
Emp_Designation varchar2(50),
Emp_Gender varchar2(1),
Emp_Marital_Status varchar2(10),
Emp_Home_Address varchar2(100),
Emp_Contact_num varchar2(15),
Constraint pk_emp Primary key(emp_id),
Constraint fk_grade FOREIGN KEY(Emp_Grade) REFERENCES Grade_Master(Grade_Code), 
Constraint fk_dept FOREIGN KEY(Emp_Dept_ID) REFERENCES Department(Dept_ID),
Constraint fk_user FOREIGN KEY(Emp_ID) REFERENCES User_Master(UserId));

select * from Employee;

