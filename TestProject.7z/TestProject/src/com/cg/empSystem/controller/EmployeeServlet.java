package com.cg.empSystem.controller;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.empSystem.dto.Employee;
import com.cg.empSystem.exception.EmployeeException;
import com.cg.empSystem.service.EmployeeService;
import com.cg.empSystem.service.EmployeeServiceImpl;

@WebServlet("*.do")
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private EmployeeService empService = null;
	private Employee emp = null;
    
    public EmployeeServlet() throws EmployeeException {
        empService = new EmployeeServiceImpl();
        emp = new Employee();
    }

    
    
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request,response);
		} catch (EmployeeException | SQLException e) {
			e.printStackTrace();
		}
	}



	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request,response);
		} catch (EmployeeException | SQLException e) {
			e.printStackTrace();
		}
	}

	private void processRequest(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException, EmployeeException, SQLException {
		String path = request.getServletPath();
		System.out.println(path);
		if(path.equals("/home.do")){
			RequestDispatcher dispatch = request.getRequestDispatcher("login.jsp");
		 	dispatch.forward(request, response);
		}
		else if(path.equals("/authenticate.do")){
			System.out.println("inside admin login controller");
			String userName = request.getParameter("ename");
			String userPassword = request.getParameter("epsw");
			// System.out.println(adminName);
			// System.out.println(adminPass);
			int res = empService.isValid(userName, userPassword);
			System.out.println(res);
			if (res == 0) {
				request.setAttribute("errorMsg", "oopss wrong password!!!!!! ");
				RequestDispatcher dispatch = request
						.getRequestDispatcher("login.jsp");
				dispatch.forward(request, response);

			}
			if (res == 1) {

				RequestDispatcher dispatch = request
						.getRequestDispatcher("admin.jsp");
				dispatch.forward(request, response);
			}

			if (res == 2) {

				RequestDispatcher dispatch = request
						.getRequestDispatcher("employee.jsp");
				dispatch.forward(request, response);
			}

			if (res == 3) {

				request.setAttribute("errorMsg", "oopss wrong username!!!!!! ");
				RequestDispatcher dispatch = request
						.getRequestDispatcher("login.jsp");
				dispatch.forward(request, response);

			}

		}// end of Authentication
		
		else if(path.equals("/addEmployee.do")){
			try {

				emp.setEmpId(request.getParameter("empId"));
				emp.setEmpFname(request.getParameter("empFname"));
				emp.setEmpLname(request.getParameter("empLname"));
				String dstr1 = request.getParameter("empDateOfBirth");
				Date d1 = Date.valueOf(dstr1);
				emp.setEmpDateOfBirth(d1);
				String dstr2 = request.getParameter("empDateOfJoining");
				Date d2 = Date.valueOf(dstr2);
				emp.setEmpDateOfJoining(d2);
				emp.setEmpDeptId(Integer.parseInt(request
						.getParameter("empDeptId")));
				emp.setEmpGrade(request.getParameter("empGrade"));
				emp.setEmpDesignation(request.getParameter("empDesignation"));
				emp.setEmpBasic(Integer.parseInt(request.getParameter("empBasic")));
				emp.setEmpContactNo(request.getParameter("empContactNo"));
				emp.setEmpGender(request.getParameter("empGender"));
				emp.setEmpMaritalStatus(request.getParameter("empMaritalStatus"));
				emp.setEmpHomeAddress(request.getParameter("empHomeAddress"));
				int st = empService.addEmployeeDetails(emp);
				if (st == 1) {
					RequestDispatcher dispatch = request
							.getRequestDispatcher("added.jsp");
					dispatch.forward(request, response);
				} else {
					request.setAttribute("errorMsg","Error in adding employee data");
					RequestDispatcher dispatch = request
							.getRequestDispatcher("error.jsp");
					dispatch.forward(request, response);
				}
			} catch (NumberFormatException e) {
				e.printStackTrace();
			} catch (EmployeeException e) {
				e.printStackTrace();
			}
		}
		
		else if(path.equals("/deleteEmployee.do")){
			String empId=request.getParameter("empId");
			try {
				boolean status = empService.removeEmployeeDetails(empId);
				request.setAttribute("employee", empId);
				RequestDispatcher dispatch = request.getRequestDispatcher("employeeDeleted.jsp");
				dispatch.forward(request, response);

			} catch (EmployeeException e) {
				request.setAttribute("message",
						"Wrong employee Id ");
				RequestDispatcher dispatch = request.getRequestDispatcher("error.jsp");
				dispatch.forward(request, response);

			}

		}
		else if(path.equals("/viewAllEmp.do")){
			List<Employee> myList = empService.showAll();
			request.setAttribute("empData",myList);
			RequestDispatcher dispatch = request.getRequestDispatcher("employeeList.jsp");
		 	dispatch.forward(request, response);
		}
		else if(path.equals("/updateForm.do")){
			String empId = request.getParameter("empId");
			
			Employee employee=empService.searchEmployeeOnId(empId);
			if(employee!=null){
				request.setAttribute("employee",employee);
			RequestDispatcher dispatch = request.getRequestDispatcher("updateForm.jsp");
		 	dispatch.forward(request, response);
			}
			else{
				RequestDispatcher dispatch = request.getRequestDispatcher("error.jsp");
			 	dispatch.forward(request, response);
			}
		}
		else if(path.equals("/submitUpdateForm.do")){
			emp.setEmpId(request.getParameter("empid"));
			emp.setEmpFname(request.getParameter("empFname"));
			emp.setEmpLname(request.getParameter("empLname"));
			String dstr1 = request.getParameter("empDateOfBirth");
			Date d1 = Date.valueOf(dstr1);
			emp.setEmpDateOfBirth(d1);
			String dstr2 = request.getParameter("empDateOfJoining");
			Date d2 = Date.valueOf(dstr2);
			emp.setEmpDateOfJoining(d2);
			emp.setEmpDeptId(Integer.parseInt(request
					.getParameter("empDeptId")));
			emp.setEmpGrade(request.getParameter("empGrade"));
			emp.setEmpDesignation(request.getParameter("empDesignation"));
			emp.setEmpBasic(Integer.parseInt(request.getParameter("empBasic")));
			emp.setEmpContactNo(request.getParameter("empContactNo"));
			emp.setEmpGender(request.getParameter("empGender"));
			emp.setEmpMaritalStatus(request.getParameter("empMaritalStatus"));
			emp.setEmpHomeAddress(request.getParameter("empHomeAddress"));
			Employee employee = empService.updateEmployee(emp);
			if (emp!=null) {
				RequestDispatcher dispatch = request
						.getRequestDispatcher("employeeUpdated.jsp");
				dispatch.forward(request, response);
			} else {
				request.setAttribute("errorMsg","Error in updating employee data");
				RequestDispatcher dispatch = request
						.getRequestDispatcher("error.jsp");
				dispatch.forward(request, response);
			}
		}
		if (path.equals("/searchEmployeeOnId.do")) {

			try {
				Employee employee = empService.searchEmployeeOnId(request
						.getParameter("empId"));
				System.out.println(employee);
				request.setAttribute("emp", employee);
				RequestDispatcher dispatch = request.getRequestDispatcher("employeeList.jsp");
				dispatch.forward(request, response);

			} catch (EmployeeException e) {
				System.out.println("problem in result of  SearchEmployeeOnId");
				request.setAttribute("message",
						"OOoopss!!!!! something went wrong please try again ");
				RequestDispatcher dispatch = request.getRequestDispatcher("searchEmployeeOnId.jsp");
				dispatch.forward(request, response);

			}

		}
		if (path.equals("/searchEmployeeOnFirstName.do")) {

			try {
				List<Employee> employee = empService.searchEmployeeOnFirstName(request
						.getParameter("empFname"));
				request.setAttribute("employee", employee);
				RequestDispatcher dispatch = request.getRequestDispatcher("employeeList.jsp");
				dispatch.forward(request, response);

			} catch (EmployeeException e) {
				System.out.println("problem in result of  SearchEmployeeOnId");
				request.setAttribute("message",
						"OOoopss!!!!! something went wrong please try again ");
				RequestDispatcher dispatch = request.getRequestDispatcher("searchEmployeeOnFirstName.jsp");
				dispatch.forward(request, response);

			}

		}
		if (path.equals("/searchEmployeeOnLastName.do")) {

			try {
				List<Employee> employee = empService.searchEmployeeOnLastName(request
						.getParameter("empFname"));
				request.setAttribute("employee", employee);
				RequestDispatcher dispatch = request.getRequestDispatcher("employeeList.jsp");
				dispatch.forward(request, response);

			} catch (EmployeeException e) {
				System.out.println("problem in result of  SearchEmployeeOnId");
				request.setAttribute("message",
						"OOoopss!!!!! something went wrong please try again ");
				

			}

		}
		
		//Start of search employee on department
		if(path.equals("/searchEmployeeOnDepartment.do")){
			
			try {
				String[] departments=request.getParameterValues("empDeptId");
				
					for (String department : departments) {
						List<Employee> empDept=empService.searchEmployeeOnDepartment(department);	
						request.setAttribute("empDept", empDept);
					}
					RequestDispatcher dispatch=request.getRequestDispatcher("employeeDepartmentList.jsp");
					dispatch.forward(request,response);
			} catch (EmployeeException e) {
				System.out.println(e.getMessage());
				request.setAttribute("message", e.getMessage());
				RequestDispatcher dispatch = request.getRequestDispatcher("searchEmployeeOnDepartment.jsp");
				dispatch.forward(request, response);
				
			}
			
		}//End of Search Employee On Department
		
		//Start of search employee on grade
				if(path.equals("/searchEmployeeOnGrade.do")){
					
					try {
						String[] grades=request.getParameterValues("empGrade");
						
							for (String grade : grades) {
								List<Employee> empGrade=empService.searchEmployeeOnGrade(grade);	
								request.setAttribute("empGrade", empGrade);
								
							}
							RequestDispatcher dispatch=request.getRequestDispatcher("employeeGradeList.jsp");
							dispatch.forward(request,response);
					} catch (EmployeeException e) {
						System.out.println(e.getMessage());
						request.setAttribute("message", e.getMessage());
						RequestDispatcher dispatch = request.getRequestDispatcher("searchEmployeeOnGrade.jsp");
						dispatch.forward(request, response);
						
					}
					
				}//End of Search Employee On grade
				
				//Start of search employee on marital status
				if(path.equals("/searchEmployeeOnMaritalStatus.do")){
					
					try {
						String[] statuses=request.getParameterValues("empMaritalStatus");
						
							for (String status : statuses) {
								List<Employee> empStatus=empService.searchEmployeeOnGrade(status);	
								request.setAttribute("empStatus", empStatus);
							}
							RequestDispatcher dispatch=request.getRequestDispatcher("employeeMaritalList.jsp");
							dispatch.forward(request,response);
					} catch (EmployeeException e) {
						System.out.println(e.getMessage());
						request.setAttribute("message", e.getMessage());
						RequestDispatcher dispatch = request.getRequestDispatcher("searchEmployeeOnMaritalStatus.jsp");
						dispatch.forward(request, response);
						
					}
					
				}//End of Search Employee On marital status
				
		
	}
}
