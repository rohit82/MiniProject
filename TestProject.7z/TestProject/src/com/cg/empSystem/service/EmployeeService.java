package com.cg.empSystem.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.empSystem.dto.Employee;
import com.cg.empSystem.exception.EmployeeException;

public interface EmployeeService {
	int addEmployeeDetails(Employee emp) throws EmployeeException;
	boolean removeEmployeeDetails(String empId) throws EmployeeException, SQLException;
	List<Employee> showAll() throws EmployeeException, SQLException;
	int	isValid(String userName,String userPassword)throws EmployeeException;
	Employee searchEmployeeOnId(String EmpId)throws EmployeeException;
	List<Employee> searchEmployeeOnFirstName(String firstName) throws EmployeeException;
	List<Employee> searchEmployeeOnLastName(String lastName) throws EmployeeException;
	List<Employee> searchEmployeeOnDepartment(String deptName) throws EmployeeException;
	List<Employee> searchEmployeeOnGrade(String grade) throws EmployeeException;
	List<Employee> searchEmployeeOnMaritalStatus(String status) throws EmployeeException;
	Employee updateEmployee(Employee emp)throws EmployeeException;

	
}
