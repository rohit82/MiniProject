package com.cg.empSystem.service;


import java.sql.SQLException;
import java.util.List;

import com.cg.empSystem.dao.EmployeeDao;
import com.cg.empSystem.dao.EmployeeDaoImpl;
import com.cg.empSystem.dto.Employee;
import com.cg.empSystem.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService{
	EmployeeDao empDao = null;
	public EmployeeServiceImpl() throws EmployeeException {
		empDao = new EmployeeDaoImpl();
	}
	//Start Of Add Employee
	@Override
	public int addEmployeeDetails(Employee emp) throws EmployeeException {
		try {
			int status=empDao.addEmployeeDetails(emp);
			return status;
		} catch (EmployeeException e) {
			throw new EmployeeException("Insertion Can not Be Done On Database!!!!!!!");
		}
		
	}// End Of Add Employee
	
	// Start of Remove Employee
	@Override
	public boolean removeEmployeeDetails(String empId) throws EmployeeException, SQLException {
		try {
			boolean checkRemove=empDao.RemoveEmployeeDetails(empId);
			return checkRemove;
		} catch (EmployeeException e) {
			throw new EmployeeException("Deletion Can't Be Done On Database!!!!!!!");
		}
	}//End Of Remove Employee
	
	//Start Of Show All
	@Override
	public List<Employee> showAll() throws EmployeeException, SQLException {
		try {
			List<Employee> empList=empDao.showAll();
			return empList;
		} catch (EmployeeException e) {
		throw new EmployeeException("Data Can't Retrieved From Database!!!!!!");
		}
	}//End Of Show All
	
	//Start Of Valid Login
	@Override
	public int isValid(String userName, String userPassword)
			throws EmployeeException {
		try {
			int data=empDao.isValid(userName, userPassword);
			return data;
		} catch (EmployeeException e) {
			throw new EmployeeException("Login Can't be Done!!!!!!!!");
		}
	}//End Of Valid login
	
	//Start Of Search Employee On Id
	@Override
	public Employee searchEmployeeOnId(String EmpId) throws EmployeeException {
		try {
			Employee emp=empDao.searchEmployeeOnId(EmpId);
			return emp;
		} catch (EmployeeException e) {
			throw new EmployeeException("Search Can't Be Done On Basis Of Your Employee Id!!!!!!!");
		}
	
	}//End of Search Employee On Id
	
	//Start of Search Employee on First name
	@Override
	public List<Employee> searchEmployeeOnFirstName(String firstName)
			throws EmployeeException {
		try {
			List<Employee> empFirstNameList=empDao.searchEmployeeOnFirstName(firstName);
			return empFirstNameList;
		} catch (EmployeeException e) {
			throw new EmployeeException("Search Can't be Done On Basis Of Your Entered First Name!!!!!!!!");
		}
	}//End of Search Employee on First name
	
	//Start of Search Employee on Last name
	@Override
	public List<Employee> searchEmployeeOnLastName(String lastName)
			throws EmployeeException {
		try {
			List<Employee> empLastNameList=empDao.searchEmployeeOnFirstName(lastName);
			return empLastNameList;
		} catch (EmployeeException e) {
			throw new EmployeeException("Search Can't be Done On Basis Of Your Entered Last Name!!!!!!!!");
		}
	}//End of Search Employee on last name
	
	//Start Of Search Employee on Department name
	@Override
	public List<Employee> searchEmployeeOnDepartment(String deptName)
			throws EmployeeException {
		try {
			List<Employee> empDeptAndEmpList=empDao.searchEmployeeOnFirstName(deptName);
			return empDeptAndEmpList;
		} catch (EmployeeException e) {
			throw new EmployeeException("Search Can't be Done On Basis Of Your Selected Department Names!!!!!!!!");
		}
	}//End Of Search Employee on Last name
	
	//Start of Search Employee on Grade
	@Override
	public List<Employee> searchEmployeeOnGrade(String grade)
			throws EmployeeException {
		try {
			List<Employee> empGradeAndEmpList=empDao.searchEmployeeOnFirstName(grade);
			return empGradeAndEmpList;
		} catch (EmployeeException e) {
			throw new EmployeeException("Search Can't be Done On Basis Of Your Selected Grades!!!!!!!!");
		}
	}//End of Search Employee on Grade
	
	//Start of Search Employee on Marital Status
	@Override
	public List<Employee> searchEmployeeOnMaritalStatus(String status)
			throws EmployeeException {
		try {
			List<Employee> empMaritalList=empDao.searchEmployeeOnFirstName(status);
			return empMaritalList;
		} catch (EmployeeException e) {
			throw new EmployeeException("Search Can't be Done On Basis Of Your Selected Marital Status!!!!!!!!");
		}
	}//End Of Search Employee on Marital Status
	
	
	//Start of update employee
	@Override
	public Employee updateEmployee(Employee emp) throws EmployeeException {
		try {
			Employee employee=empDao.updateEmployee(emp);
			
			return employee;
		} catch (EmployeeException e) {
			throw new EmployeeException("Update Can't be Done On Basis Of your Provided Data!!!!!!!!!!!!");
		}
	}//End of update employee
	

	
}
