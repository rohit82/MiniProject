package com.cg.service;


import com.cg.bean.Employee;
import com.cg.dao.IEmployeeDAOImpl;
import com.cg.dao.IEmployeeDAO;
import com.cg.exception.EmployeeException;

public class IEmployeeServiceImpl implements IEmployeeService {
	
private IEmployeeDAO employeeDAO;
	
	public IEmployeeServiceImpl(){
		
		employeeDAO = new IEmployeeDAOImpl();
	}
	

	@Override
	public int addEmployee(Employee employee) throws EmployeeException {
		
		return employeeDAO.addEmployee(employee);
	}

	@Override
	public Employee getEmployee(int empId) throws EmployeeException {
		
		return employeeDAO.getEmployee(empId);
	}

	@Override
	public Employee getEmployeeDetailsByFName(String Fname)
			throws EmployeeException {
		
		return employeeDAO.getEmployeeDetailsByFName(Fname);
	}

	@Override
	public Employee getEmployeeDetailsByLName(String Lname)
			throws EmployeeException {
		
		return employeeDAO.getEmployeeDetailsByLName(Lname);
	}


	@Override
	public Employee getEmployeeByDept(int deptId) throws EmployeeException {
		
		return employeeDAO.getEmployeeByDept(deptId);
	}

}
