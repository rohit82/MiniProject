package com.cg.controller;

import java.io.IOException;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.Employee;
import com.cg.service.IEmployeeService;
import com.cg.service.IEmployeeServiceImpl;


@WebServlet(urlPatterns={"/EmployeeController", "/AddEmployee","/Success"})
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	IEmployeeService service = new IEmployeeServiceImpl();
       public EmployeeController() {
        super();
        
    }
	
	protected void doGet(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException
	{
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException
	{
		IEmployeeService service = new IEmployeeServiceImpl();
		String path=request.getServletPath();
		System.out.println(path);
		String url= null;
		
		switch(path)
		{
		
		case "/AddEmployee":
			
			
			
			//Date birth	
			String Emp_Date_of_Birth = request.getParameter("txtDOB");
			
			/*SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
			  
			 Date date=null;
			 try {
				date=formatter.parse(Emp_Date_of_Birth);
			} catch (ParseException e) {
				
				e.printStackTrace();
			}
			 java.sql.Date birthDate = new java.sql.Date(date.getTime());*/	
			Date birthDate = Date.valueOf(Emp_Date_of_Birth) ;
			
			 
			 
			 
			 // JOINING
			 String Emp_Date_of_Joining = request.getParameter("txtDOJ");
				
				/*SimpleDateFormat formatter1 = new SimpleDateFormat("dd-MM-yyyy");
				  
				 Date date1=null;
				 try {
					date1=formatter.parse(Emp_Date_of_Joining);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				 java.sql.Date joinDate = new java.sql.Date(date.getTime());*/
			 
			 Date joinDate = Date.valueOf(Emp_Date_of_Joining);
		
				 
				 Employee emp = new Employee();
				 emp.setFname(request.getParameter("txtFName"));
				 emp.setLname(request.getParameter("txtLName"));
				 emp.setDOB(birthDate);
				 emp.setDOJ(joinDate);
				 emp.setDeptId(Integer.parseInt(request.getParameter("txtDept")));
				 emp.setGrade(request.getParameter("grade"));
				 emp.setDesignation(request.getParameter("txtDesg"));
				 emp.setBasic(Integer.parseInt(request.getParameter("txtBSal")));
				 emp.setGender(request.getParameter("gender"));
				 emp.setMaritalStatus(request.getParameter("Mstatus"));
				 emp.setHomeAddress(request.getParameter("txtHAddr"));
				 emp.setCNum(request.getParameter("txtMNumber"));
				 
				
				int id=service.addEmployee(emp);
				
					request.setAttribute("empId",id );
					System.out.println(id);
					url="Success.jsp";
				 
			
			break;
		}
		
		RequestDispatcher rd = request.getRequestDispatcher(url) ;
		rd.forward(request, response);
		
	}

}
