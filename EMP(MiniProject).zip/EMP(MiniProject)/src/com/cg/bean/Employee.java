package com.cg.bean;

import java.sql.Date;

public class Employee {
	
	
/*	Emp_ID VARCHAR2(6), Emp_First_Name VARCHAR2(25), 
	Emp_Last_Name VARCHAR2(25), Emp_Date_of_Birth DATE, 
	Emp_Date_of_Joining DATE, Emp_Dept_ID int, Emp_Grade VARCHAR2(2), 
	Emp_Designation VARCHAR2(50), Emp_Basic int, Emp_Gender VARCHAR2(1),
	Emp_Marital_Status VARCHAR2(1), Emp_Home_Address VARCHAR2(100),
	Emp_Contact_Num VARCHAR2(15)*/
	
	private int empId;
	private String Fname;
	private String Lname;
	private Date DOB;
	private Date DOJ;
	private int deptId;
	private String grade;
	private String designation;
	private int basic;
	private String gender;
	private String MaritalStatus;
	private String HomeAddress;
	private String CNum;
	public Employee() {
		super();
	}
	public Employee(int empId, String fname, String lname, Date dOB, Date dOJ,
			int deptId, String grade, String designation, int basic,
			String gender, String maritalStatus, String homeAddress, String cNum) {
		super();
		this.empId = empId;
		Fname = fname;
		Lname = lname;
		DOB = dOB;
		DOJ = dOJ;
		this.deptId = deptId;
		this.grade = grade;
		this.designation = designation;
		this.basic = basic;
		this.gender = gender;
		MaritalStatus = maritalStatus;
		HomeAddress = homeAddress;
		CNum = cNum;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getFname() {
		return Fname;
	}
	public void setFname(String fname) {
		Fname = fname;
	}
	public String getLname() {
		return Lname;
	}
	public void setLname(String lname) {
		Lname = lname;
	}
	public Date getDOB() {
		return DOB;
	}
	public void setDOB(Date dOB) {
		DOB = dOB;
	}
	public Date getDOJ() {
		return DOJ;
	}
	public void setDOJ(Date dOJ) {
		DOJ = dOJ;
	}
	public int getDeptId() {
		return deptId;
	}
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public int getBasic() {
		return basic;
	}
	public void setBasic(int basic) {
		this.basic = basic;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMaritalStatus() {
		return MaritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		MaritalStatus = maritalStatus;
	}
	public String getHomeAddress() {
		return HomeAddress;
	}
	public void setHomeAddress(String homeAddress) {
		HomeAddress = homeAddress;
	}
	public String getCNum() {
		return CNum;
	}
	public void setCNum(String cNum) {
		CNum = cNum;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", Fname=" + Fname + ", Lname="
				+ Lname + ", DOB=" + DOB + ", DOJ=" + DOJ + ", deptId="
				+ deptId + ", grade=" + grade + ", designation=" + designation
				+ ", basic=" + basic + ", gender=" + gender
				+ ", MaritalStatus=" + MaritalStatus + ", HomeAddress="
				+ HomeAddress + ", CNum=" + CNum + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((CNum == null) ? 0 : CNum.hashCode());
		result = prime * result + empId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (CNum == null) {
			if (other.CNum != null)
				return false;
		} else if (!CNum.equals(other.CNum))
			return false;
		if (empId != other.empId)
			return false;
		return true;
	}
	
	
	

	
	
	

}
