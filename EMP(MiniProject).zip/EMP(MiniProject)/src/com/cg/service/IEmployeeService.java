package com.cg.service;

import com.cg.bean.Employee;
import com.cg.exception.EmployeeException;

public interface IEmployeeService {
	
	public int addEmployee(Employee employee) throws EmployeeException;
	public Employee getEmployee(int empId) throws EmployeeException;
	public Employee getEmployeeDetailsByFName(String Fname) throws EmployeeException;
	public Employee getEmployeeDetailsByLName(String Lname) throws EmployeeException;
	public Employee getEmployeeByDept(int deptId) throws EmployeeException;



}
