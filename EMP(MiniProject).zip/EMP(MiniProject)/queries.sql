create table Employee1(Emp_ID VARCHAR2(6), Emp_First_Name VARCHAR2(25), 
	 Emp_Last_Name VARCHAR2(25), Emp_Date_of_Birth DATE, Emp_Date_of_Joining DATE,
	 Emp_Dept_ID int, Emp_Grade VARCHAR2(2), Emp_Designation VARCHAR2(50),
	 Emp_Basic int, Emp_Gender VARCHAR2(1), Emp_Marital_Status VARCHAR2(1),
	 Emp_Home_Address VARCHAR2(100), Emp_Contact_Num VARCHAR2(15));
	 
	create table Department(Dept_ID int, Dept_Name VARCHAR2(50));
	
	create table User_Master(UserId VARCHAR2(6), UserName VARCHAR2(15), 
	UserPassword VARCHAR2(50), UserType VARCHAR2(10));
	
	create table Grade_Master(Grade_Code VARCHAR2(2), Description VARCHAR2(10), Min_Salary int,
	Max_Salary int);
